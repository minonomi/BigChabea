class ClientsidesController < ApplicationController
    before_action :set_customer, only: [:show, :edit, :update, :destroy]
    before_action :set_event, only: [:show, :edit, :update, :destroy]




    
    
    
    def customer_index
        @customer = Customer.find(params[:id])
        @event = Event.new
        
        
        render :layout => 'regcustomer'
    end

    
    def customer_reg_form

        @customer = Customer.new
        
        @customers = Customer.all
        
        render :layout => 'customer'
    end
    
    
    
    def events
        @events = Event.where(:customer_id => params[:id])
        @customer = Customer.find(params[:id])
    
        render :layout => 'regcustomer'
    end
        
        
        

    def create        
        @event = Event.new(event_params)
    
    respond_to do |format|
      if @event.save
          format.html { redirect_to "/myevents/#{@event.customer_id}", notice: 'Event was successfully created.' }
        format.json { render :show, status: :created, location: @event }
      else
        format.html { render :new }
        format.json { render json: @event.errors, status: :unprocessable_entity }
            end
        end
    end





      def create2
    @customer = Customer.new(customer_params)

    respond_to do |format|
      if @customer.save
          format.html { redirect_to "/bigchabea/#{@customer.id}", notice: 'Customer was successfully created.' }
        format.json { render :show, status: :created, location: @customer }
      else
        format.html { render :new }
        format.json { render json: @customer.errors, status: :unprocessable_entity }
      end
    end
  end


  private
    # Use callbacks to share common setup or constraints between actions.
    def set_customer
      @customer = Customer.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def customer_params
      params.require(:customer).permit(:Firstname, :Middlename, :Lastname, :Address, :Email, :Contact_Number)
    end
    

    # Use callbacks to share common setup or constraints between actions.
    def set_event
      @event = Event.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def event_params
      params.require(:event).permit(:event_type, :no_of_guest, :venue, :event_date, :time, :other_services, :Total, :customer_id)
    end




end
