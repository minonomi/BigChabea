class OrderListsController < ApplicationController
  before_action :set_order_list, only: [:show, :edit, :update, :destroy]


  # GET /order_lists
  # GET /order_lists.json
  def index
    @order_lists = OrderList.all
  end

  # GET /order_lists/1
  # GET /order_lists/1.json
  def show
  end

  # GET /order_lists/new
  def new
    @order_list = OrderList.new
      @id = params[:id]
  end

  # GET /order_lists/1/edit
  def edit
  end

  # POST /order_lists
  # POST /order_lists.json
  def create
    @order_list = OrderList.new(order_list_params)
      
      
    respond_to do |format|
      if @order_list.save

            @foodprice = Food.find(@order_list.food_id)
            @eventup = Event.find(@order_list.event_id)
          
          if @order_list.quantity == nil || @order_list.quantity <= 0
              OrderList.where(:id => @order_list.id).update_all(:quantity => 1)          
          end
          

          newtotal = @eventup.Total + (@foodprice.price * @order_list.quantity)
          Event.where(:id => @order_list.event_id).update_all(:Total => newtotal)
          
          olnewtotal = @foodprice.price * @order_list.quantity          
          OrderList.where(:id => @order_list.id).update_all(:Total => olnewtotal) 
          
          format.html { redirect_to "/events/#{@order_list.event_id}" }
        format.json { render :show, status: :created, location: @order_list }
      else
        format.html { render :new }
        format.json { render json: @order_list.errors, status: :unprocessable_entity }
      end
    end
  end
    
    
  # PATCH/PUT /order_lists/1
  # PATCH/PUT /order_lists/1.json
  def update
    respond_to do |format|
      if @order_list.update(order_list_params)
        format.html { redirect_to @order_list, notice: 'Order list was successfully updated.' }
        format.json { render :show, status: :ok, location: @order_list }
      else
        format.html { render :edit }
        format.json { render json: @order_list.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /order_lists/1
  # DELETE /order_lists/1.json
  def destroy
      
          @foodprice = Food.find(@order_list.food_id)
          @eventup = Event.find(@order_list.event_id)
      @newtotal = @eventup.Total - (@foodprice.price * @order_list.quantity)
          Event.where(:id => @order_list.event_id).update_all(:Total => @newtotal)
      
    @order_list.destroy
    respond_to do |format|
      format.html { redirect_to "/events/#{@order_list.event_id}" }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_order_list
      @order_list = OrderList.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def order_list_params
      params.require(:order_list).permit(:food_id, :event_id, :quantity)
    end
    
end
