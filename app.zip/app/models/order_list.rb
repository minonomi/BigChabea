class OrderList < ActiveRecord::Base
    belongs_to :event
    belongs_to :food
end
