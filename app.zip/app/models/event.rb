class Event < ActiveRecord::Base
    belongs_to :customer
    has_many :order_lists
end
