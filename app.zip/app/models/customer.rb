class Customer < ActiveRecord::Base
    has_many :events 
end
