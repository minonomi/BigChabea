class CreateOrderLists < ActiveRecord::Migration
  def change
    create_table :order_lists do |t|
      t.integer :food_id
      t.integer :event_id
      t.integer :quantity

      t.timestamps null: false
    end
  end
end
