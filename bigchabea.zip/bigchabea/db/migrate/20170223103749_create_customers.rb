class CreateCustomers < ActiveRecord::Migration
  def change
    create_table :customers do |t|
      t.string :Firstname
      t.string :Middlename
      t.string :Lastname
      t.string :Address
      t.string :Email
      t.string :Contact_Number

      t.timestamps null: false
    end
  end
end
