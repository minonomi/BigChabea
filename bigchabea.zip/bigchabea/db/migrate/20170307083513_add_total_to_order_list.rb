class AddTotalToOrderList < ActiveRecord::Migration
  def change
    add_column :order_lists, :Total, :integer
  end
end
