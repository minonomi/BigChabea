class AddTotalToEvent < ActiveRecord::Migration
  def change
    add_column :events, :total, :integer
      add_column :events, :customer_id, :integer
  end
end
