class CreateEvents < ActiveRecord::Migration
  def change
    create_table :events do |t|
      t.string :event_type
      t.integer :no_of_guest
      t.string :venue
      t.date :event_date
      t.string :time
      t.string :other_services

      t.timestamps null: false
    end
  end
end
