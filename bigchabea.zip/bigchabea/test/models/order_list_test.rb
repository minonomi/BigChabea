require 'test_helper'

class OrderListTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
