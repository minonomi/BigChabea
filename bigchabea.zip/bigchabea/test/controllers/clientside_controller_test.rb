require 'test_helper'

class ClientsideControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
