require 'test_helper'

class ClientsidesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
